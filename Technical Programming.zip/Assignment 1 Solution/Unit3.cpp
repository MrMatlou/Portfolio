﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TmagnifyWords *magnifyWords;
//---------------------------------------------------------------------------
__fastcall TmagnifyWords::TmagnifyWords(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

//Task 1- Defining method that will and extract a single word, e.g word number 1 , 2 or 3
AnsiString TmagnifyWords::getFieldByNr(AnsiString aLine, int fieldNr, char delimiter)
{
	aLine += delimiter;
	int pos;
	AnsiString field;
	for (int i = 1; i <= fieldNr; i++) {
		pos = aLine.Pos(delimiter);

		//some additional code which is not really neccessary
		if (pos == 0) {
			sptCount->Value = i - 1;
		  return field;
		}

		field = aLine.SubString(1, pos - 1);
		aLine.Delete(1, pos);
	}

	return field;
}

//Task 2 - getting the path for an image
AnsiString TmagnifyWords::getImagePathName(char letter){
	  AnsiString imagePath = "";
	  if (letter == ' ') {
		  imagePath = "..\\..\\Characters\\Space.jpg";
	  }
	  else{
		  imagePath = "..\\..\\Characters\\"+AnsiString(letter)+".jpg";
	  }
	return imagePath;
}

//Task 3
void __fastcall TmagnifyWords::btnGrabClick(TObject *Sender)
{
	// userSentence and grabbedWord are member variables
	//AnsiString userSentence ,grabbedWord;

	int wordNumber;
	img1->Top = 168; //resetting it's position since it'll be dropped
	img1->Visible = true;  //making sure it's visible
	img2->Visible = true;  //making sure it's visible since it'll disappear
	img3->Top = 168;  //same comment as img1
	img3->Visible = true;   //same comment as img1
	img4->Visible = true;  //same comment as img2

	userSentence = edtWords->Text.UpperCase(); //getting the sentence and making it uppercase
	wordNumber = sptCount->Value;
	grabbedWord = getFieldByNr(userSentence,wordNumber,' ');

	//Check if the world might be less than needed Since all words must be
	//4 characters long, we add spaces until it makes up the required 4 characters
	if (grabbedWord.Length() < 4) {
		for (int i = 1; i <= 4 - (grabbedWord.Trim().Length()); i++) {
			grabbedWord += " ";
		}
	}
	//loading images to the image controls
	img1->Picture->LoadFromFile(getImagePathName(grabbedWord[1]));
	img2->Picture->LoadFromFile(getImagePathName(grabbedWord[2]));
	img3->Picture->LoadFromFile(getImagePathName(grabbedWord[3]));
	img4->Picture->LoadFromFile(getImagePathName(grabbedWord[4]));
}
//---------------------------------------------------------------------------

void __fastcall TmagnifyWords::btnClearClick(TObject *Sender)
{
	lstSWords->Items->Add(grabbedWord);  //adding the word to the list box
	tmrClear->Enabled = true;   //starting the timer so it can do the rest
}
//---------------------------------------------------------------------------

void __fastcall TmagnifyWords::tmrClearTimer(TObject *Sender)
{
	if (img3->Visible) {    //if img3 is still visible...
	   img3->Top = img3->Top + 5; // we continue dropping it 5 units down

	   if (img3->Top >= 330 ) {  // if it has reached 330, that means it's no longer visible...
		   img3->Visible = false; // we change it's property to indicate that it's no longer visible
	   }
	}

	if (img1->Visible) {  //same comments as img3
	   img1->Top = img1->Top + 3;   // except that img1 drops by 3 units meaning it'll be a bit slower than img1

	   if (img1->Top >= 330 ) {
		   img1->Visible = false;
	   } 
	}
	
	if (!img1->Visible && !img3->Visible) {  //if both img1 and img3 are no longer visible...
		img2->Visible = false;               //we also make img2 and img4 invisible
		img4->Visible = false;               
		tmrClear->Enabled = false;           //we also stop the timer because "the work is done" 😎
	}
}
//---------------------------------------------------------------------------


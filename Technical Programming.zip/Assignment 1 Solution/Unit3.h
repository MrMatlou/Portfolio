//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <jpeg.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Samples.Spin.hpp>
//---------------------------------------------------------------------------
class TmagnifyWords : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TEdit *edtWords;
	TTimer *tmrClear;
	TListBox *lstSWords;
	TLabel *Label2;
	TLabel *Label3;
	TSpinEdit *sptCount;
	TButton *btnGrab;
	TButton *btnClear;
	TImage *img1;
	TImage *img2;
	TImage *img3;
	TImage *img4;
	void __fastcall btnGrabClick(TObject *Sender);
	void __fastcall btnClearClick(TObject *Sender);
	void __fastcall tmrClearTimer(TObject *Sender);
private:	// User declarations
		AnsiString userSentence ,grabbedWord;
public:		// User declarations
	__fastcall TmagnifyWords(TComponent* Owner);
	AnsiString getFieldByNr(AnsiString aLine, int fieldNr, char delimiter);
	AnsiString getImagePathName(char );

};
//---------------------------------------------------------------------------
extern PACKAGE TmagnifyWords *magnifyWords;
//---------------------------------------------------------------------------
#endif
